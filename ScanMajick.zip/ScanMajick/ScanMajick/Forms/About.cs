﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScanMajick.Forms
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
            label1.Text = "Unauthorised duplication and distribution of this program or any part of it may result in severe civil  and criminal penalties";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
