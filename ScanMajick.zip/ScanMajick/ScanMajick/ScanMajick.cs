﻿using PdfSharp.Drawing;
using PdfSharp.Pdf;
using ScanMajick.Class;
using ScanMajick.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WIATest;

namespace ScanMajick
{
    public partial class ScanMajick : Form
    {

        //private bool _dragging = false;
        //private Point _offset;
        //private Point _start_point = new Point(0, 0);

        //List<Image> img;

        List<String> listImages;

        static int alreadyScanned = 0;
        static int repetition = 1;
        string button_name;
        Button dynamicButton;

        static string folderPath, whereToSave;

        //MainClass mc;

        ToolTip tp;
        public ScanMajick()
        {

            InitializeComponent();

            panelButtons.Controls.Clear();

            if (Properties.Settings.Default.folderPath != "")
            {
                folderPath = Properties.Settings.Default.folderPath;
                lblFolder.Text = Properties.Settings.Default.folderPath;
                if (Directory.Exists(folderPath))
                {
                    // Directory exits!
                }
                else
                {
                    // Directory dosn't exits.
                    folderPath = Environment.SpecialFolder.Desktop.ToString();
                    lblFolder.Text = folderPath;
                    //
                    //Save a new defaul
                    Properties.Settings.Default["folderPath"] = folderPath;
                    Properties.Settings.Default.Save();
                }
            }
            else
            {
                folderPath = Environment.SpecialFolder.Desktop.ToString();
                lblFolder.Text = folderPath;
            }


            DoToolTip();

        }

        private void DoToolTip()
        {
            tp = new ToolTip();
            tp.UseFading = true;
            tp.UseAnimation = true;
            tp.IsBalloon = true;
            tp.ShowAlways = true;
            tp.AutoPopDelay = 5000;
            tp.InitialDelay = 1000;
            tp.ReshowDelay = 500;
            tp.SetToolTip(btnNew, "Start a new scan");
        }

        private void ScanMajick_Load(object sender, EventArgs e)
        {
            DateTime now = DateTime.Today;
            txtAcYear.Text = now.ToString("yyyy");

            //mc = new MainClass();
            //mc.Tooltip(this);

            txtAcName.Text = "";

        }
        public void StartForm()
        {
            // Application.Run(new SplashScreen());
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            if (txtPages.Text == "")
            {
                MessageBox.Show("Please specify correct page no.", "Invalid page number", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPages.Focus();
                return;
            }
            int totalPages = Convert.ToInt16(txtPages.Text);

            if (totalPages < 1 || totalPages > 10)
            {
                MessageBox.Show("Please specify correct page no.", "Invalid page number", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPages.Focus();
                return;
            }
            if (repetition == 11)
            {
                MessageBox.Show("Limit reached!!");
                return;
            }

            btn_ok.Enabled = false;

            listImages = new List<String>();


            for (int i = 0; i < totalPages; i++)
            {
                //
                // Create a Button object 
                dynamicButton = new Button();

                //dynamicButton.Click 
                dynamicButton.Location = new Point(1, +repetition * 40);

                dynamicButton.Height = 40;
                dynamicButton.Width = 220;

                // Set background and foreground
                dynamicButton.ForeColor = Color.White;


                dynamicButton.Text = "Scan Page " + repetition.ToString();
                button_name = "DynamicButton_" + repetition.ToString();
                dynamicButton.Name = button_name;// "DynamicButton" + repetition.ToString();

                dynamicButton.FlatStyle = FlatStyle.Standard;

                dynamicButton.Tag = repetition;

                dynamicButton.Click += new System.EventHandler(dynamicButton_Click);
                repetition++;

                addControls(dynamicButton);
            }

            // Create a Convert Button object 
            dynamicButton = new Button();

            dynamicButton.Location = new Point(1, +repetition * 45);

            dynamicButton.Height = 40;
            dynamicButton.Width = 220;

            // Set background and foreground
            dynamicButton.ForeColor = Color.White;

            dynamicButton.BackColor = Color.White;
            dynamicButton.ForeColor = Color.Blue;

            dynamicButton.Text = "Convert To PDf";
            button_name = "convertButton";
            dynamicButton.Name = button_name;
            dynamicButton.Image = new Bitmap(Properties.Resources.icons8_scanner_20px);
            dynamicButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;


            dynamicButton.Click += new System.EventHandler(convertButton_Click);
            repetition++;

            addControls(dynamicButton);
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            int remaining = (Convert.ToInt16(txtPages.Text) - alreadyScanned);

            MessageBox.Show(remaining.ToString());

            //Button bt = (Button)sender;

            //MessageBox.Show("" + bt.Name.ToString());

            foreach (String item in listImages)
            {
                // MessageBox.Show(item);
            }

            if (remaining != 0)
            {
                MessageBox.Show("You have not scanned all the pages." + Environment.NewLine + "Make sure all pages are scanned before you convert.", "Scan all pages", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            convertToPdf();
        }

        private void btnTestPdf_Click(object sender, EventArgs e)
        {
            string mydocpath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\ifeanyi_2020";

            listImages = new List<string>();

            foreach (string file in Directory.GetFiles(mydocpath, "*.jpeg"))
            {
                listImages.Add(file);
                //MessageBox.Show(file);
            }

            convertToPdf();
        }

        private void convertToPdf()
        {
            // Create a new PDF document
            PdfDocument document = new PdfDocument();
            //document.Info.Title = "Created with PDFsharp";
            //document.Info.Author = "Stefan Lange";
            //document.Info.Subject = "Created with code snippets that show the use of graphical functions";
            //document.Info.Keywords = "PDFsharp, XGraphics";



            foreach (String item in listImages)
            {

                // Create an empty page
                PdfPage page = document.AddPage();

                page.Size = PdfSharp.PageSize.A4;
                page.Orientation = PdfSharp.PageOrientation.Portrait;


                //page.Width =

                //page.Height = ;

                // Get an XGraphics object for drawing
                XGraphics gfx = XGraphics.FromPdfPage(page);

                // Create a font
                //XFont font = new XFont("Verdana", 20, XFontStyle.BoldItalic);

                // ScaleImage(Image.FromFile(item), 600, 900);

                XImage xImage = XImage.FromFile(item);


                //gfx.DrawImage(xImage, xPosition, yPosition, xImage.PixelWidth, xImage.PixelWidth);
                //gfx.DrawImage(xImage, 0, 0, xImage.PointHeight, xImage.PointWidth);

                // Left position in point
                //http://www.pdfsharp.net/wiki/Graphics-sample.ashx#Draw_an_image_in_original_size_20
                //Draw an image in original size
                double x = (250 - xImage.PixelWidth * 72 / xImage.HorizontalResolution) / 2;

                gfx.DrawImage(xImage, 30, 20, 500, 750); //gfx.DrawImage(image, x, 0); / y is margin on top

                //gfx.DrawImage(xImage, 0, 100, xImage.PixelWidth, xImage.PixelWidth);

                /////
                //resize image here
                /////
                //Image img = Image.FromFile(item);
                //img = ResizeImageKeepAspectRatio(img, 540, 900);
                //img.Save(item + ".jpeg");

            }

            string file = folderPath + "\\" + txtAcName.Text + "_" + txtAcYear.Text + "\\" + txtAcName.Text + "_" + txtAcYear.Text + ".pdf";

            if (File.Exists(file))
            {
                // //delete or warn throw new FileNotFoundException(String.Format("Could not find image {0}.", file));
            }

            // Save the document...
            string filename = file;// "e:\\" + "HelloWorld.pdf";
            document.Save(filename);
            // ...and start a viewer.
            Process.Start(filename);


            //
        }

        /// <summary>
        /// Resize an image keeping its aspect ratio (cropping may occur).
        /// </summary>
        /// <param name="source"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <returns></returns>
        /// https://alex.domenici.net/archive/resize-and-crop-an-image-keeping-its-aspect-ratio-with-c-sharp
        /// 
        private Image ResizeImageKeepAspectRatio(Image source, int width, int height)
        {
            Image result = null;

            try
            {
                if (source.Width != width || source.Height != height)
                {
                    // Resize image
                    float sourceRatio = (float)source.Width / source.Height;

                    using (var target = new Bitmap(width, height))
                    {
                        using (var g = System.Drawing.Graphics.FromImage(target))
                        {
                            g.CompositingQuality = CompositingQuality.HighQuality;
                            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                            g.SmoothingMode = SmoothingMode.HighQuality;

                            // Scaling
                            float scaling;
                            float scalingY = (float)source.Height / height;
                            float scalingX = (float)source.Width / width;
                            if (scalingX < scalingY) scaling = scalingX; else scaling = scalingY;

                            int newWidth = (int)(source.Width / scaling);
                            int newHeight = (int)(source.Height / scaling);

                            // Correct float to int rounding
                            if (newWidth < width) newWidth = width;
                            if (newHeight < height) newHeight = height;

                            // See if image needs to be cropped
                            int shiftX = 0;
                            int shiftY = 0;

                            if (newWidth > width)
                            {
                                shiftX = (newWidth - width) / 2;
                            }

                            if (newHeight > height)
                            {
                                shiftY = (newHeight - height) / 2;
                            }

                            // Draw image
                            g.DrawImage(source, -shiftX, -shiftY, newWidth, newHeight);
                        }

                        result = new Bitmap(target);
                    }
                }
                else
                {
                    // Image size matched the given size
                    result = new Bitmap(source);
                }
            }
            catch (Exception)
            {
                result = null;
            }

            whereToSave = folderPath + "\\" + txtAcName.Text + "_" + txtAcYear.Text + "\\";
            //MessageBox.Show(whereToSave);
            //bmp.Save(whereToSave + DateTime.Now.ToString("yyyy-MM-dd HHmmss") + "_toto.jpeg", ImageFormat.Jpeg);

            return result;



            //return bmp;
        }
        private void dynamicButton_Click(object sender, EventArgs e)
        {
            if (txtAcName.Text == "")
            {
                MessageBox.Show("Enter the account name", "Missing information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtAcName.Focus();
                return;
            }

            if (txtAcYear.Text == "")
            {
                MessageBox.Show("Enter the year for this account ", "Missing information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtAcYear.Focus();
                return;
            }

            //TEST SCANNER HERE
            //get list of devices available
            List<string> devices = WIAScanner.GetDevices();

            foreach (string device in devices)
            {
                // MessageBox.Show(device);
            }

            //MessageBox.Show(devices.Count.ToString());
            //check if device is not available
            if (devices.Count < 0)
            //if (lbDevices.Items.Count == 0)
            {
                MessageBox.Show("You do not have any scanner connected." + Environment.NewLine + "Make sure you have a scanner connected and powered on.", "Scanner not detected!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            //change button
            Button btn = (Button)sender;
            btn.Image = new Bitmap(Properties.Resources.icons8_tick_box_30px);
            btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btn.Enabled = false;
            btn.Text = "Done";


            ScanImageToDisk(btn.Tag.ToString());
        }


        private void ScanImageToDisk(string id)
        {

            //MessageBox.Show("I want to scan " + id);


            whereToSave = folderPath + "\\" + txtAcName.Text + "_" + txtAcYear.Text + "\\";

            //MessageBox.Show("Where to save is " + whereToSave);

            try
            {
                //make folder
                MakeDirectory(whereToSave);
                //Process.Start("explorer.exe", whereToSave);

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            try
            {
                //get list of devices available
                List<string> devices = WIAScanner.GetDevices();

                foreach (string device in devices)
                {
                    lbDevices.Items.Add(device);
                }

                //check if device is not available
                if (lbDevices.Items.Count == 0)
                {
                    MessageBox.Show("You do not have any WIA devices.");
                    //this.Close();
                    return;
                }
                else
                {
                    lbDevices.SelectedIndex = 0;
                }


                alreadyScanned += 1;

                string fileTime;

                //get images from scanner
                List<Image> images = WIAScanner.Scan((string)lbDevices.SelectedItem);
                foreach (Image image in images)
                {
                    pic_scan.Image = image;
                    pic_scan.Show();
                    pic_scan.SizeMode = PictureBoxSizeMode.StretchImage;
                    pic_scan.SizeMode = PictureBoxSizeMode.Normal;

                    //save scanned image into specific folder

                    //image.Save(whereToSave + "" + id + "_" + DateTime.Now.ToString("yyyy-MM-dd HHmmss") + ".jpeg", ImageFormat.Jpeg); //image.Save(@"E:\" + DateTime.Now.ToString("yyyy-MM-dd HHmmss") + ".jpeg", ImageFormat.Jpeg);
                    //listImages.Add(whereToSave + "" + id + "_"+ DateTime.Now.ToString("yyyy-MM-dd HHmmss") + ".jpeg");

                    fileTime = DateTime.Now.ToString("yyyy-MM-dd HHmmss");
                    image.Save(whereToSave + "" + id + "_" + fileTime + ".jpeg", ImageFormat.Jpeg);

                    image.Save(whereToSave + "" + id + "_" + fileTime + ".png", ImageFormat.Png);

                    listImages.Add(whereToSave + "" + id + "_" + fileTime + ".jpeg");
                }



            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void addControls(Control uc)
        {
            panelButtons.Controls.Add(uc);
            uc.BringToFront();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you really want to quit?", "Close program", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No)
            {
                return;
            }
            Application.Exit();
        }


        private void btn_scan_Click(object sender, EventArgs e)
        {

            whereToSave = folderPath + "\\" + txtAcName + "\\_" + txtAcYear + "\\";
            //txtAcName.Text = whereToSave;

            try
            {
                //make folder
                MakeDirectory(whereToSave);
                // Process.Start("explorer.exe", whereToSave);

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            try
            {
                //get list of devices available
                List<string> devices = WIAScanner.GetDevices();

                foreach (string device in devices)
                {
                    lbDevices.Items.Add(device);
                }
                //check if device is not available
                if (lbDevices.Items.Count == 0)
                {
                    MessageBox.Show("You do not have any WIA devices.");
                    this.Close();
                }
                else
                {
                    lbDevices.SelectedIndex = 0;
                }
                //get images from scanner
                List<Image> images = WIAScanner.Scan((string)lbDevices.SelectedItem);
                foreach (Image image in images)
                {
                    pic_scan.Image = image;
                    pic_scan.Show();
                    pic_scan.SizeMode = PictureBoxSizeMode.StretchImage;
                    //save scanned image into specific folder

                    //image.Save(@"E:\" + DateTime.Now.ToString("yyyy-MM-dd HHmmss") + ".jpeg", ImageFormat.Jpeg);
                    image.Save(whereToSave + DateTime.Now.ToString("yyyy-MM-dd HHmmss") + ".jpeg", ImageFormat.Jpeg);

                    listImages.Add(whereToSave + DateTime.Now.ToString("yyyy-MM-dd HHmmss") + ".jpeg");
                }

            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void MakeDirectory(string whereToSave)
        {

            if (!Directory.Exists(whereToSave))
            {
                try
                {
                    Directory.CreateDirectory(whereToSave);
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                //Erase all entries //
                DirectoryInfo di = new DirectoryInfo(whereToSave);

                foreach (FileInfo file in di.GetFiles())
                {
                    //MessageBox.Show(file.ToString()); 
                    try
                    {
                        // file.Delete();
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(ex.ToString());
                    }
                }


            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
            panelButtons.Controls.Clear();
            txtAcName.Text = "";
            txtAcName.Focus();
            repetition = 1;
            btn_ok.Enabled = true;
            pic_scan.InitialImage = null;

            using (AccountDetail ac = new AccountDetail())
            {
                //ac.ShowDialog();
                //this.onLoad(e) // to reload this calling form
            }
        }



        private void btnChangeFolder_Click(object sender, EventArgs e)
        {
            // Show the FolderBrowserDialog.  
            DialogResult result = FolderBrowserDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                lblFolder.Text = FolderBrowserDialog.SelectedPath;

                Properties.Settings.Default["folderPath"] = FolderBrowserDialog.SelectedPath;
                Properties.Settings.Default.Save();

                Environment.SpecialFolder root = FolderBrowserDialog.RootFolder;

            }
        }

        private void btnMinimise_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            using (About ab = new About())
            {
                ab.ShowDialog();
            }
        }


    }
}
