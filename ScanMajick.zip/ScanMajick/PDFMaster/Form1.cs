﻿using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.Advanced;
using PdfSharp.Pdf.IO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PDFMaster
{
    public partial class Form1 : Form
    {
        List<Image> imageList;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //string path = Environment.SpecialFolder.Desktop + "\\ikpu";// "C:\\Junk";
            string path =  "E:\\";
            DirectoryInfo dir = new DirectoryInfo(path);
            String name;

            imageList = new List<Image>();
            //Image img;
            foreach (FileInfo flInfo in dir.GetFiles())
            {
                name = flInfo.Name;
                listBox1.Items.Add(name);
                //img = new Image;
                //var img = Image.FromFile("e:\\" + name);
                //imageList.Add(img); 
                //long size = flInfo.Length;
                //DateTime creationTime = flInfo.CreationTime;
                //Console.WriteLine("{0, -30:g} {1,-12:N0} {2} ", name, size, creationTime);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string img = "e:\\" + listBox1.SelectedItem.ToString();
                //MessageBox.Show(img);
                pictureBox1.Image = Image.FromFile(img);
                convertToPdf(img);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="imgList"></param>
        /// <param name="filePath"></param>
        private void createPDFDocument(List<Image> imgList, string filePath)
        {
            foreach (Image img in imgList)
            {

            }
        }

        private void convertToPdf(string file)
        {
            // Create a new PDF document
            PdfDocument document = new PdfDocument();
            document.Info.Title = "Created with PDFsharp";

            // Create an empty page
            PdfPage page = document.AddPage();

            // Get an XGraphics object for drawing
            XGraphics gfx = XGraphics.FromPdfPage(page);

            // Create a font
            XFont font = new XFont("Verdana", 20, XFontStyle.BoldItalic);

            // Draw the text
            //gfx.DrawString("Hello, World!", font, XBrushes.Black, new XRect(0, 0, page.Width, page.Height),  XStringFormats.Center);


            if (!File.Exists(file))
            {
                throw new FileNotFoundException(String.Format("Could not find image {0}.", file));
            }

            XImage xImage = XImage.FromFile(file);
            //gfx.DrawImage(xImage, xPosition, yPosition, xImage.PixelWidth, xImage.PixelWidth);
            gfx.DrawImage(xImage, 10, 10, xImage.PixelWidth, xImage.PixelWidth);

            // Save the document...
            const string filename = "e:\\" + "HelloWorld.pdf";
            document.Save(filename);
            // ...and start a viewer.
            Process.Start(filename);


            //
        }

        public static void imagesToPdf(string[] images, string pdfName)
        {

            using (PdfDocument pdf = new PdfDocument())
            {
                

                //pdf.Save(pdfName);
            }
        }

        private void btnFolderSelect_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowNewFolderButton = true;
            //.InitialDirectory = "C:\\Users";
            // Show the FolderBrowserDialog.  
            DialogResult result = folderDlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                textBox1.Text = folderDlg.SelectedPath;
                Environment.SpecialFolder root = folderDlg.RootFolder;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
