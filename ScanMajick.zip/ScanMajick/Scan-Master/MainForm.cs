﻿//using ScannerDemo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WIA;

namespace Scan_Master
{

    public enum WIAPageSize
    {
        A4, // 8.3 x 11.7 in  (210 x 297 mm)
        Letter, // 8.5 x 11 in (216 x 279 mm)
        Legal, // 8.5 x 14 in (216 x 356 mm)
    }

    public enum WIAScanQuality
    {
        Preview,
        Final,
    }

    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }


        private void Main_Load(object sender, EventArgs e)
        {
            ListScanners();

            // Set start output folder TMP
            textBox1.Text = Path.GetTempPath();
            // Set JPEG as default
            comboBox1.SelectedIndex = 1;

        }

        private void ListScanners()
        {
            // Clear the ListBox.
            listBox1.Items.Clear();

            // Create a DeviceManager instance
            var deviceManager = new DeviceManager();

            // Loop through the list of devices and add the name to the listbox
            for (int i = 1; i <= deviceManager.DeviceInfos.Count; i++)
            {
                // Add the device only if it's a scanner
                if (deviceManager.DeviceInfos[i].Type != WiaDeviceType.ScannerDeviceType)
                {
                    continue;
                }

                // Add the Scanner device to the listbox (the entire DeviceInfos object)
                // Important: we store an object of type scanner (which ToString method returns the name of the scanner)
                listBox1.Items.Add(
                    new Scanner(deviceManager.DeviceInfos[i])
                );
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Task.Factory.StartNew(StartScanning).ContinueWith(result => TriggerScan());
        }

        private void TriggerScan()
        {
            Console.WriteLine("Image succesfully scanned");
        }

        public void StartScanning()
        {
            Scanner device = null;

            this.Invoke(new MethodInvoker(delegate ()
            {
                device = listBox1.SelectedItem as Scanner;
            }));

            if (device == null)
            {
                MessageBox.Show("You need to select first an scanner device from the list",
                                "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else if (String.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Provide a filename",
                                "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ImageFile image = new ImageFile();
            string imageExtension = "";

            this.Invoke(new MethodInvoker(delegate ()
            {
                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        image = device.ScanPNG();
                        imageExtension = ".png";
                        break;
                    case 1:
                        image = device.ScanJPEG();
                        imageExtension = ".jpeg";
                        break;
                    case 2:
                        image = device.ScanTIFF();
                        imageExtension = ".tiff";
                        break;
                }
            }));


            // Save the image
            var path = Path.Combine(textBox1.Text, textBox2.Text + imageExtension);

            if (File.Exists(path))
            {
                File.Delete(path);
            }

            image.SaveFile(path);

            pictureBox1.Image = new Bitmap(path);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowNewFolderButton = true;
            DialogResult result = folderDlg.ShowDialog();

            if (result == DialogResult.OK)
            {
                textBox1.Text = folderDlg.SelectedPath;
            }
        }

        private void btnScanPreview_Click(object sender, EventArgs e)
        {
            //this.doScan(WIAScanQuality.Preview);
        }

        private void btnScanHighQuality_Click(object sender, EventArgs e)
        {
            //this.doScan(WIAScanQuality.Final);
        }

        private void doScan(WIAScanQuality scanQuality)
        {
            /*
             * Taken from C:\Users\Anyison\Desktop\ScannerApplication\WIADemo-master\WIADemo-master
              try
              {
                  //get list of devices available

                  if (lbDevices.Items.Count == 0)
                  {
                      MessageBox.Show("You do not have any WIA devices.");

                  }
                  else
                  {
                      // get the selected scanner
                      var device = devices[lbDevices.SelectedIndex];

                      //get images from scanner
                      var pages_to_scan = 1;
                      images = WIAScanner.Scan(device.DeviceID, pages_to_scan, scanQuality, WIAPageSize.Legal);
                      pages = images.Count;
                      if (images != null)
                      {
                          foreach (Image image in images)
                          {
                              pic_scan.Image = images[0];
                              pic_scan.Show();
                              pic_scan.SizeMode = PictureBoxSizeMode.StretchImage;
                              currentImage = new Bitmap(images[0]);
                              btnScanHighQuality.Enabled = true;
                              btnSave.Enabled = true;
                              currentPage = 0;
                          }
                      }
                  }
              }
              catch (Exception exc)
              {
                  MessageBox.Show(exc.Message);
              }
            */
        }
    }
}
